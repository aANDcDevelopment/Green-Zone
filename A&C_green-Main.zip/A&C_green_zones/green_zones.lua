-- Configuration for green zones
local greenZones = {
    {center = vector3(100.0, 200.0, 30.0), radius = 50.0},  -- Example coordinates and radius
    {center = vector3(-200.0, 300.0, 50.0), radius = 75.0}
}

-- Function to check if a player is in a green zone
local function isInGreenZone(playerPos)
    for _, zone in ipairs(greenZones) do
        local dist = #(playerPos - zone.center)
        if dist < zone.radius then
            return true
        end
    end
    return false
end

-- Event listener for player entering/exiting green zones
AddEventHandler('playerEnteredGreenZone', function()
    local playerPed = PlayerPedId()
    local playerPos = GetEntityCoords(playerPed)

    if isInGreenZone(playerPos) then
        -- Disable shooting and driving
        TriggerEvent('disableShootingAndDriving')
        -- Show prompt
        TriggerEvent('chat:addMessage', {
            color = {255, 0, 0},
            multiline = true,
            args = {"~r~You are in a green zone. Shooting and driving are disabled."}
        })
    else
        -- Enable shooting and driving when leaving green zone
        TriggerEvent('enableShootingAndDriving')
    end
end)

-- Sample functions to disable/enabled shooting and driving
AddEventHandler('disableShootingAndDriving', function()
    -- Disable shooting
    DisableControlAction(0, 24, true) -- Disable weapon firing
    DisableControlAction(0, 75, true) -- Disable aiming
    -- Disable driving controls
    DisableControlAction(0, 29, true) -- Vehicle forward
    DisableControlAction(0, 30, true) -- Vehicle backward
    DisableControlAction(0, 31, true) -- Vehicle left
    DisableControlAction(0, 32, true) -- Vehicle right
end)

AddEventHandler('enableShootingAndDriving', function()
    -- Enable shooting
    EnableControlAction(0, 24, true) -- Enable weapon firing
    EnableControlAction(0, 75, true) -- Enable aiming
    -- Enable driving controls
    EnableControlAction(0, 29, true) -- Vehicle forward
    EnableControlAction(0, 30, true) -- Vehicle backward
    EnableControlAction(0, 31, true) -- Vehicle left
    EnableControlAction(0, 32, true) -- Vehicle right
end)
